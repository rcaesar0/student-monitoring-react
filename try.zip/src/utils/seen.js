// "Seen by" for announcements and activities.
// A guardian's account remembers the posts they opened in Updates (viewedPosts).
export const postKey = (kind, id) => `${kind}-${id}`;

// The guardians who can see a room: approved link to a student in that room.
export function guardiansOfRoom(db, roomId) {
  const kids = new Set(db.roomStudents.filter((x) => x.roomId === roomId).map((x) => x.studentId));
  const ids = new Set(db.guardianLinks.filter((l) => l.status === 'Approved' && kids.has(l.studentId)).map((l) => l.guardianId));
  return db.guardians.filter((g) => ids.has(g.id) && g.status !== 'Archived');
}

export const hasSeen = (guardian, key) => (guardian.viewedPosts || []).includes(key);