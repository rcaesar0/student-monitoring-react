import React, { useState } from 'react';
import { Modal, Badge } from './UI';
import { useApp } from '../context/AppContext';
import { fullName } from '../utils/helpers';
import { guardiansOfRoom, hasSeen, postKey } from '../utils/seen';

// "Seen by 3 of 5 guardians" under a post. Tap it to see who has opened it and who has not yet.
export default function SeenBy({ room, kind, post }) {
  const { db } = useApp();
  const [open, setOpen] = useState(false);
  const guardians = guardiansOfRoom(db, room.id);
  if (!guardians.length) return null;
  const key = postKey(kind, post.id);
  const seen = guardians.filter((g) => hasSeen(g, key));

  return (
    <>
      <button type="button" className="text-btn seen-btn" onClick={() => setOpen(true)}>
        Seen by {seen.length} of {guardians.length} guardian{guardians.length > 1 ? 's' : ''}
      </button>
      {open && (
        <Modal title={`Seen by · ${post.title}`} onClose={() => setOpen(false)}>
          {guardians.map((g) => (
            <div className="row" key={g.id}>
              <span><b>{fullName(g)}</b></span>
              <Badge tone={hasSeen(g, key) ? 'green' : 'neutral'}>{hasSeen(g, key) ? 'Seen' : 'Not yet'}</Badge>
            </div>
          ))}
          <p className="hint">A guardian counts as having seen a post once they open it in Updates.</p>
        </Modal>
      )}
    </>
  );
}