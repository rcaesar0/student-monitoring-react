import React from 'react';
import { Panel, Empty, Badge } from './UI';
import { useApp } from '../context/AppContext';
import { fullName, dateStr, formatDate } from '../utils/helpers';
import { flaggedIn } from '../utils/risk';

// Teacher dashboard: students who may need help, found by simple rules on attendance and grades (see utils/risk.js).
// Nothing reaches a guardian until the teacher reviews the reasons and presses Notify.
export default function EarlyWarningPanel({ rooms }) {
  const { db, repo, user } = useApp();
  const list = flaggedIn(db, rooms);
  const guardiansOf = (studentId) => db.guardianLinks.filter((l) => l.studentId === studentId && l.status === 'Approved').length;

  function notify(x) {
    const text = `Send an alert to the guardian of ${fullName(x.student)}?\n\nThe guardian will see:\n• ${x.reasons.join('\n• ')}`;
    if (!window.confirm(text)) return;
    repo.add('alerts', {
      kind: 'risk', studentId: x.student.id, roomId: x.room.id, teacherId: user.id,
      reasons: x.reasons, date: dateStr(), at: Date.now(),
    });
  }

  return (
    <Panel title="Early warning" actions={list.length ? <Badge tone="amber">{list.length}</Badge> : null}>
      <p className="hint">Based on attendance and grades. Review the reasons, then notify the guardian if it helps.</p>
      {list.length ? (
        list.map((x) => (
          <div className="list-card" key={`${x.room.id}-${x.student.id}`}>
            <div className="row-actions spread">
              <b>{fullName(x.student)}</b>
              <Badge tone={x.level === 'high' ? 'red' : 'amber'}>{x.level === 'high' ? 'Needs attention' : 'Watch'}</Badge>
            </div>
            <small>{x.room.subject} · {x.room.name}</small>
            <ul className="reasons">{x.reasons.map((r) => <li key={r}>{r}</li>)}</ul>
            <div className="row-actions">
              {x.sent
                ? <small>Guardian notified {formatDate(x.sent.date)}</small>
                : guardiansOf(x.student.id)
                  ? <button className="btn-sm" onClick={() => notify(x)}>Notify guardian</button>
                  : <small>No linked guardian yet.</small>}
            </div>
          </div>
        ))
      ) : (
        <Empty text="No students need a closer look right now." />
      )}
    </Panel>
  );
}