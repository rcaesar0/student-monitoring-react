import React from 'react';
import { useLang } from '../utils/i18n';

// Small button for the sign-in screens: switches between English and Filipino.
export default function LanguageSwitch() {
  const { lang, setLang } = useLang();
  return (
    <button type="button" className="theme-float lang-float" onClick={() => setLang(lang === 'fil' ? 'en' : 'fil')} aria-label="Language">
      {lang === 'fil' ? 'EN' : 'FIL'}
    </button>
  );
}