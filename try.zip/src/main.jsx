import React from 'react';
import { createRoot } from 'react-dom/client';
import { AppProvider } from './context/AppContext';
import { LanguageProvider } from './utils/i18n';
import App from './App';
import './styles/global.css';

createRoot(document.getElementById('root')).render(
  <LanguageProvider>
    <AppProvider>
      <App />
    </AppProvider>
  </LanguageProvider>
);
